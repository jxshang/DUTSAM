# Dataset 

## Description

Due to the privacy of QAR data, we selected 20 flight segment samples as a small data set to be disclosed.
There are some descriptions about dataset.

path = DUTSAM/dataset/A320/hupsampling
--one csv file contains 50 seconds of data before and after landing.
--"time" represents the touchdown time point or the maximum VRTG point.
--label = 0(non-hard landing)/1(hard landing)

path = DUTSAM/dataset/0
--one csv file contains 30 seconds of data before the maximum VRTG point.

path = DUTSAM/dataset/2
--one csv file contains the first 28 seconds of the above 30 seconds of data.

path = DUTSAM/dataset/4
--one csv file contains the first 26 seconds of the above 26 seconds of data.

